// interactivity: burger, reviews slider, form validation
document.addEventListener('DOMContentLoaded', function(){
  const burger = document.getElementById('burger');
  const nav = document.querySelector('.nav');
  if(burger && nav){
    burger.addEventListener('click', ()=> nav.classList.toggle('open'));
  }

  // Simple reviews slider (shows one slide at a time)
  const slider = document.querySelector('.reviews-slider');
  const prev = document.getElementById('prev-review');
  const next = document.getElementById('next-review');
  let current = 0;
  const slides = slider ? slider.querySelectorAll('.review') : [];
  function showSlide(i){
    if(!slider) return;
    current = (i + slides.length) % slides.length;
    slider.style.transform = `translateX(-${current * 100}%)`;
  }
  showSlide(0);
  prev && prev.addEventListener('click', ()=> showSlide(current - 1));
  next && next.addEventListener('click', ()=> showSlide(current + 1));

  // Form validation + send to console (placeholder for real backend)
  const form = document.getElementById('order-form');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const phone = document.getElementById('phone');
      if(!phone || phone.value.trim().length < 6){
        alert('Пожалуйста, укажите корректный телефон.');
        phone && phone.focus();
        return;
      }
      // collect data
      const data = new FormData(form);
      const obj = {};
      data.forEach((v,k) => {
        if(obj[k]){
          if(Array.isArray(obj[k])) obj[k].push(v);
          else obj[k] = [obj[k], v];
        } else obj[k] = v;
      });
      console.log('Order form submitted (placeholder):', obj);
      alert('Заявка принята. Мы свяжемся с вами в ближайшее время.');
      form.reset();
    });
  }

  // Simple reveal on scroll for elements with .card-small, .service-card, .work-item
  const revealEls = document.querySelectorAll('.card-small, .service-card, .work-item, .review');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting) entry.target.style.opacity = 1, entry.target.style.transform = 'translateY(0)';
    });
  }, {threshold: 0.15});
  revealEls.forEach(el => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(18px)';
    el.style.transition = 'all 600ms cubic-bezier(.2,.9,.2,1)';
    io.observe(el);
  });
});
