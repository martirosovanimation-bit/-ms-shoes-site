
// Burger menu
document.addEventListener('DOMContentLoaded', function(){
  const burger = document.getElementById('burger');
  const nav = document.getElementById('main-nav');
  burger && burger.addEventListener('click', function(){
    nav.classList.toggle('open');
  });

  // Simple form validation
  const orderForm = document.getElementById('order-form');
  if(orderForm){
    orderForm.addEventListener('submit', function(e){
      const phone = document.getElementById('phone');
      if(!phone || phone.value.trim().length < 10){
        e.preventDefault();
        alert('Пожалуйста, укажите корректный телефон.');
        phone && phone.focus();
        return false;
      }
      // If using Netlify forms, allow native submit
    });
  }

  // Scroll reveal (simple)
  const reveal = () => {
    document.querySelectorAll('.card, .service, .review').forEach(el => {
      const rect = el.getBoundingClientRect();
      if(rect.top < window.innerHeight - 60){
        el.style.opacity = 1;
        el.style.transform = 'translateY(0)';
      } else {
        el.style.opacity = 0;
        el.style.transform = 'translateY(18px)';
      }
    });
  };
  document.addEventListener('scroll', reveal);
  reveal();
});
